Another *small* Super Mario Bros clone (with half the resolution of the original one)

This project aims to showcase the steps needed to create a platformer game from scratch (with almost no library at all)&nbsp;- using one of the most played ones as a "template".</p>
In this demo project, there's the full **world 1x1** level - and a not fully playable **world 1x2**

**No sound support** (for now)

**Top score** isn't saved between sessions.
**Left - Right** to move - **Up** to jump - **Ctrl** to fire (when in Fire mode)
The C source code and gfx of this fan/educational game are available on github

download project page: https://marcogiorgini.itch.io/supermb-64
github page: https://github.com/MGProduction/SuperMB64
author: @marcogiorgini